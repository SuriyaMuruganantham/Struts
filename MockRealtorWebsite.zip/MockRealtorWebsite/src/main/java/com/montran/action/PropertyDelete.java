package com.montran.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.PropertyDeleteForm;
import com.montran.pojo.PropertyAdd;
import com.montran.service.PropertyService;

public class PropertyDelete extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		 
		PropertyAdd property = new PropertyAdd();
		PropertyDeleteForm propertyform=(PropertyDeleteForm)form;
		PropertyService propertyImpl = new PropertyService();
		property.setId(propertyform.getId());
		propertyImpl.deleteproperty(property);
		return mapping.findForward("success");	
	}
	

}

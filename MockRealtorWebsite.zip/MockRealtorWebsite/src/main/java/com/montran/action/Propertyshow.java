package com.montran.action;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.PropertyShowForm;
import com.montran.pojo.PropertyAdd;
import com.montran.service.PropertyService;


public class Propertyshow extends Action{
	

	public ActionForward execute(ActionMapping mapping,ActionForm form,
    		HttpServletRequest request,HttpServletResponse response) 
            throws Exception {
   
    		PropertyService propertyImpl = new PropertyService();
    		PropertyShowForm propertyform=(PropertyShowForm)form;
    	
    		List<PropertyAdd> propertylist =  new ArrayList<PropertyAdd>();
    		propertylist = propertyImpl.showAllproperty();
    	
    		 /*for(PropertyAdd pro : propertylist)
 	        {
 	        	System.out.println("Id:"+pro.getId()+"Name: "+pro.getPname()+"Address:"+pro.getPaddress()+"Price:"+pro.getPrice());
 	        }*/
    		propertyform.setPropertylist(propertylist);
    		request.setAttribute("propertyshow",propertylist);
    		return mapping.findForward("show");
    	  }   
    }

package com.montran.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.UserLoginForm;
import com.montran.pojo.UserLogin;
import com.montran.service.UserLoginService;

public class UserLoginAction extends Action {

	@Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception, IOException
    {
		
		String status="";
		UserLogin user = new UserLogin();
		UserLoginForm actionForm = (UserLoginForm)form;
		UserLoginService userImpl = new UserLoginService();
		
		user.setId(actionForm.getId()); 
		user.setUserName(actionForm.getUserName());
		user.setUserPassword(actionForm.getPassword());
		
		status=userImpl.userlogin(user);
	        
		return mapping.findForward(status); 
    }	
}

package com.montran.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.TextAreaActionForm;
import com.montran.pojo.TextAreaAdd;
import com.montran.service.TextAreaService;

public class TextAreaAction extends Action
{

	public ActionForward execute(ActionMapping mapping, ActionForm  form,
			HttpServletRequest request, HttpServletResponse response)
						throws Exception {
			String status="";
			
			TextAreaActionForm texAreaActionForm=(TextAreaActionForm)form;
			TextAreaAdd text = new TextAreaAdd();
			TextAreaService textImpl = new TextAreaService();
			
			text.setId(texAreaActionForm.getId());
			text.setMessage(texAreaActionForm.getMessage());

			status = textImpl.insert(text);
			return mapping.findForward(status);
}
}
package com.montran.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.PropertyShowForm;
import com.montran.beans.TextAreaActionForm;
import com.montran.beans.TextAreaShowForm;
import com.montran.pojo.PropertyAdd;
import com.montran.pojo.TextAreaAdd;
import com.montran.service.PropertyService;
import com.montran.service.TextAreaService;

public class TextAreaShow extends Action{
	

	public ActionForward execute(ActionMapping mapping,ActionForm form,
    		HttpServletRequest request,HttpServletResponse response) 
            throws Exception {
   
			TextAreaShowForm texAreaActionForm=(TextAreaShowForm)form;
			TextAreaAdd text = new TextAreaAdd();
			TextAreaService textImpl = new TextAreaService();
    	
    		List<TextAreaAdd> textlist =  new ArrayList<TextAreaAdd>();
    		textlist = textImpl.showAllproperty();
    	
	        for(TextAreaAdd property : textlist)
	        {
	        	System.out.println("Id:"+property.getId()+"Name: "+property.getMessage());
	        }
	        
    		texAreaActionForm.setTextlist(textlist);
    		request.setAttribute("list",textlist);
    		return mapping.findForward("show");
    	  }   
}

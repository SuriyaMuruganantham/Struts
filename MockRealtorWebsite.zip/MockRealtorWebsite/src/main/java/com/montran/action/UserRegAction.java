package com.montran.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.UserRegForm;
import com.montran.pojo.UserReg;
import com.montran.service.UserService;

public class UserRegAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String status="";
		UserRegForm actionForm = (UserRegForm)form;
		UserReg user = new UserReg();
		
		user.setId(actionForm.getId()); 
		user.setUserName(actionForm.getUserName());
		user.setUserEmail(actionForm.getUserEmail());
		user.setUserAddress(actionForm.getUserAddress());
		user.setUserPhone(actionForm.getUserPhone());
		user.setUserPassword(actionForm.getUserPassword());
		
		UserService userservice = new UserService();
		status = userservice.registration(user);
		return mapping.findForward(status);
	}
}

package com.montran.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.FinalPropertyShowForm;
import com.montran.pojo.FinalPropertyAdd;
import com.montran.service.FinalPropertyService;

public class FinalPropertyShow extends Action{
	

	public ActionForward execute(ActionMapping mapping,ActionForm form,
    		HttpServletRequest request,HttpServletResponse response) 
            throws Exception {
    	
    		FinalPropertyService propertyImpl = new FinalPropertyService();
    		FinalPropertyShowForm propertyform=(FinalPropertyShowForm)form;
    		
    		List<FinalPropertyAdd> finalpropertylist =  new ArrayList<FinalPropertyAdd>();
    		finalpropertylist = propertyImpl.showAllproperty();
    	    
    		propertyform.setPropertylist(finalpropertylist);
    		
    		request.setAttribute("finalpropertylist",finalpropertylist);
    		return mapping.findForward("finalpropshow");
    	  }

}

package com.montran.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.AdminRequestForm;
import com.montran.pojo.PropertyAdd;
import com.montran.service.AddFinalProperty;

public class AdminRequestAdd extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		 
		PropertyAdd property = new PropertyAdd();
		AdminRequestForm propertyform=(AdminRequestForm)form;
		AddFinalProperty propertyImpl = new AddFinalProperty();
		property.setId(propertyform.getId());
		propertyImpl.insert(property);
		return mapping.findForward("success");
	}

}

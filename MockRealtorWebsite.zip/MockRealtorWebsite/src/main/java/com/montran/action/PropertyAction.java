package com.montran.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.montran.beans.PropertyDetailsForm;
import com.montran.pojo.PropertyAdd;
import com.montran.service.PropertyService;


public class PropertyAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		PropertyAdd property = new PropertyAdd();
		PropertyService propertyImpl = new PropertyService();  
	        
		String status="";
		PropertyDetailsForm propertyform=(PropertyDetailsForm)form;
		
		property.setId(propertyform.getId()); 
		property.setPname(propertyform.getPname());
		property.setPaddress(propertyform.getPaddress());
		property.setPrice(propertyform.getPrice());
		property.setPcontact(propertyform.getPcontact());
	
		status = propertyImpl.saveProperty(property);
		return mapping.findForward(status);		
		
	}		 
}

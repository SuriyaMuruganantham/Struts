package com.montran.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.montran.pojo.FinalPropertyAdd;
import com.montran.util.HibernateUtil;

public class FinalPropertyService {
	
	 @SuppressWarnings({ "unchecked", "unused" })
	public List<FinalPropertyAdd> showAllproperty() {
	    	
	    	List<FinalPropertyAdd> propertylist = new ArrayList<FinalPropertyAdd>();
	    	
	        Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction tx = session.beginTransaction();
			@SuppressWarnings("rawtypes")
			Query query = session.createQuery("from FinalPropertyAdd");
	        propertylist  = query.list(); 
	       /* for(FinalPropertyAdd property : propertylist)
	        {
	        	System.out.println("Id:"+property.getId()+"Name: "+property.getPname()+"Address:"+property.getPaddress()+"Price:"+property.getPrice());
	        	System.out.println("Contact"+property.getPcontact());
	        }*/
	        return propertylist;        
	    }
}

package com.montran.service;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.montran.pojo.FinalPropertyAdd;
import com.montran.pojo.PropertyAdd;
import com.montran.util.HibernateUtil;

@SuppressWarnings("unused")
public class AddFinalProperty {
	
	public void insert(PropertyAdd property)
	{
	 Session session = HibernateUtil.getSessionFactory().openSession();
     Transaction tx = session.beginTransaction();
     PropertyAdd propertydetails = (PropertyAdd)session.load(PropertyAdd.class,property.getId());
     Query query = session.createNativeQuery("insert into finalproperty select * from propertydetail where id =:Id");
     query.setParameter("Id",property.getId());
     int result = query.executeUpdate();
     
     query = session.createNativeQuery("Delete from propertydetail where id =:Id");
     query.setParameter("Id",property.getId());
     int result1 = query.executeUpdate();
     tx.commit();
     session.close();
	}
	public void delete(PropertyAdd property)
	{
		 Session session = HibernateUtil.getSessionFactory().openSession();
	     Transaction tx = session.beginTransaction();
	     Query query = session.createNativeQuery("Delete from propertydetail where id =:Id");
	     query.setParameter("Id",property.getId());
	     int result1 = query.executeUpdate();
	     tx.commit();
	     session.close();
	}
	
}

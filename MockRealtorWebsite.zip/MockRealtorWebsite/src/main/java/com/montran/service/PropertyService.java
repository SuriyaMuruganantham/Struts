package com.montran.service;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.montran.pojo.FinalPropertyAdd;
import com.montran.pojo.PropertyAdd;
import com.montran.util.HibernateUtil;

public class PropertyService implements PropertyDao {
	
	public String saveProperty(PropertyAdd property){
		String status="";
		
		Transaction tx=null;
		try
		{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session= sessionFactory.openSession();
		PropertyAdd propdatabase=(PropertyAdd)session.get(PropertyAdd.class, property.getId());	
		FinalPropertyAdd finalprop=(FinalPropertyAdd)session.get(FinalPropertyAdd.class, property.getId());
		
		if(propdatabase==null&&finalprop==null)
		{
			tx = session.beginTransaction();
			session.save(property);
			tx.commit();
			status="success";	
		}
		else
		{
			status="existed";
		}
		}catch(Exception e)
		{
			status="failure";
			e.printStackTrace();
		}
		return status;
	}
    
	@SuppressWarnings({ "unused", "unchecked", "rawtypes" })
	@Override
    public List<PropertyAdd> showAllproperty() {
    	
    	List<PropertyAdd> propertylist = new ArrayList<PropertyAdd>();
    	
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
		Query query = session.createQuery("from PropertyAdd");
        propertylist  = query.list(); 
       
        /*for(PropertyAdd property : propertylist)
        {
        	System.out.println("Id:"+property.getId()+"Name: "+property.getPname()+"Address:"+property.getPaddress()+"Price:"+property.getPrice());
        	System.out.println("Contact"+property.getPcontact());
        }*/
        tx.commit();
        session.close();  
        return propertylist;        
    }

    @Override
    public void updateproperty (int id, String pname, String paddress, int price, int pcontact) {
    	
    	Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        PropertyAdd propertydetails = (PropertyAdd)session.load(PropertyAdd.class, id);
     
        propertydetails.setPname(pname);
        propertydetails.setPaddress(paddress);
        propertydetails.setPrice(price);
        propertydetails.setPcontact(pcontact);
        session.update(propertydetails);
        transaction.commit();
        session.close();     
    }
    	
    @Override
    public void deleteproperty (PropertyAdd property) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.delete(property);
        transaction.commit();
        session.close();
    }

}

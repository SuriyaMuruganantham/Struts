package com.montran.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.montran.pojo.UserLogin;
import com.montran.util.HibernateUtil;

public class UserLoginService {
	

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	public List<UserLogin> showAlluser() {
    	
    	List<UserLogin> userlist = new ArrayList<UserLogin>();
    	
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
		Query query = session.createQuery("from UserLogin");
		userlist  = query.list(); 
		 for(UserLogin user: userlist)
	        {
	        	System.out.println("Id:"+user.getId()+"Name: "+user.getUserName()+"Password:"+user.getUserPassword());
	        	
	        }
        return userlist; 
	}
	public String userlogin(UserLogin user) {
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session= sessionFactory.openSession();
		String status="";
	try {	
		UserLogin userDatafromDB = (UserLogin)session.get(UserLogin.class,user.getId());

	        if(userDatafromDB.getUserName()!=null && userDatafromDB.getUserPassword()!=null)
	        {
	            status ="success";
	            
	        }
	        else
	        {
	            status ="failure";
	        }
		}
	        catch(Exception e)
	        {
	        	status ="usernotexist";
	        }
		
			return status;
	}
}

package com.montran.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.montran.pojo.UserLogin;
import com.montran.pojo.UserReg;
import com.montran.util.HibernateUtil;

public class UserService {
	
	public String registration(UserReg user)
	{
		String status="";
		Transaction tx=null;
		try
		{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session= sessionFactory.openSession();
		UserLogin user1=(UserLogin)session.get(UserLogin.class, user.getId());
		if(user1==null)
		{
			tx = session.beginTransaction();
			session.save(user);
			tx.commit();
			status="success";	
		}
		else
		{
			status="existed";
		}
		}catch(Exception e)
		{
			status="failure";
			e.printStackTrace();
		}
		return status;
	}	
}
	



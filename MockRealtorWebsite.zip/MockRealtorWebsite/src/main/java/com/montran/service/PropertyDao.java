package com.montran.service;

import java.util.List;

import com.montran.pojo.PropertyAdd;

public interface PropertyDao {
	
	    
	    public String saveProperty (PropertyAdd property);
	    public List<PropertyAdd> showAllproperty();
	    public void updateproperty (int id, String pname, String paddress, int price, int pcontact);
	    public void deleteproperty (PropertyAdd property);
	

}

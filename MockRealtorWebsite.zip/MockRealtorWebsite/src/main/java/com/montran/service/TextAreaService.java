package com.montran.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.montran.pojo.PropertyAdd;
import com.montran.pojo.TextAreaAdd;
import com.montran.util.HibernateUtil;

public class TextAreaService {
	
	public String insert(TextAreaAdd text){
		
	String status="";
		
		Transaction tx=null;
		try
		{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session= sessionFactory.openSession();
		TextAreaAdd textdatabase=(TextAreaAdd)session.get(TextAreaAdd.class, text.getId());	
			
		if(textdatabase==null)
		{
			tx = session.beginTransaction();
			session.save(text);
			tx.commit();
			status="success";	
		}
		else
		{
			status="existed";
		}
		}catch(Exception e)
		{
			status="failure";
			e.printStackTrace();
		}
		return status;
	}
	
	 public List<TextAreaAdd> showAllproperty() {
	    	
	    	List<TextAreaAdd> textlist = new ArrayList<TextAreaAdd>();
	    	
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction tx = session.beginTransaction();
			Query query = session.createQuery("from TextAreaAdd");
	        textlist  = query.list(); 
	       
	        for(TextAreaAdd property : textlist)
	        {
	        	System.out.println("Id:"+property.getId()+"Name: "+property.getMessage());
	         }
	        tx.commit();
	        session.close();  
	        return textlist;        
	    }

	public void deleteproperty(TextAreaAdd text) {
		 	Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = session.beginTransaction();
	        session.delete(text);
	        transaction.commit();
	        session.close();
		
	}
		
		
}



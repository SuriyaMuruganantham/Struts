package com.montran.pojo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UserLogin implements Serializable{

	private int id;
	private String userName;
	private String userPassword;
	
	public int getId() {
		return id;
	}
	public int setId(int id) {
		return this.id = id;
	}	
	public String getUserName() {
		return userName;
	}
	public String setUserName(String userName) {
		return this.userName = userName;
	}
	
	public String getUserPassword() {
		return userPassword;
	}
	public String setUserPassword(String userPassword) {
		return this.userPassword = userPassword;
	}	
}

package com.montran.pojo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class FinalPropertyAdd implements Serializable{
	private int id;
	private String pname;
	private String paddress;
	private int price;
	private int pcontact;
	
	public int getId() {
		return id;
	}
	public int setId(int id) {
		return this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public String setPname(String pname) {
		return this.pname = pname;
	}
	public String getPaddress() {
		return paddress;
	}
	public String setPaddress(String paddress) {
		return this.paddress = paddress;
	}
	public int getPrice() {
		return price;
	}
	public int setPrice(int price) {
		return this.price = price;
	}
	public int getPcontact() {
		return pcontact;
	}
	public int setPcontact(int pcontact) {
		return this.pcontact = pcontact;
	}

}

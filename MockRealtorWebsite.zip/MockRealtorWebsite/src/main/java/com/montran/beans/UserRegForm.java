package com.montran.beans;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

@SuppressWarnings("serial")
public class UserRegForm extends ActionForm{
	
	private int id;
	private String userName;
	private String userEmail;
	private int userPhone;
	private String userAddress;
	private String userPassword;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public int getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(int userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	@Override
	public ActionErrors validate(ActionMapping mapping,HttpServletRequest request)
	{
		ActionErrors ae = new ActionErrors();
		if(id==0)
		{
			ae.add("id",new ActionMessage("msg2"));
		}
		if(userName.equals(""))
		{
			ae.add("userName",new ActionMessage("msg2"));
		}
		if(userEmail.equals(""))
		{
			ae.add("userEmail",new ActionMessage("msg2"));
		}
		
		if(userPhone==0)
		{
			ae.add("userPhone",new ActionMessage("msg2"));
		}
		if(userAddress.equals(""))
		{
			ae.add("userAddress",new ActionMessage("msg2"));
		}
		if(userPassword.equals(""))
		{
			ae.add("userPassword",new ActionMessage("msg2"));
		}
		
		return ae;
		}	
	}

	


package com.montran.beans;

import java.util.List;

import org.apache.struts.action.ActionForm;

import com.montran.pojo.TextAreaAdd;

@SuppressWarnings("serial")
public class TextAreaShowForm extends ActionForm {
	 private int id;
	 private String message;
	 List<TextAreaAdd>textlist;
	  
	  public List<TextAreaAdd> getTextlist() {
		return textlist;
	}

	public void setTextlist(List<TextAreaAdd> textlist) {
		this.textlist = textlist;
	}

	public String getMessage() {
	  return message;
	  }
	  
	  public void setMessage(String string) {
	  message = string;
	  }	 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

}

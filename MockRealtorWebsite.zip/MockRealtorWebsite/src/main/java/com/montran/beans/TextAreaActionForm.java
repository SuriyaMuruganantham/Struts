package com.montran.beans;

import java.util.List;

import org.apache.struts.action.ActionForm;

import com.montran.pojo.TextAreaAdd;

@SuppressWarnings("serial")
public class TextAreaActionForm extends ActionForm {
	 private int id;
	 private String message;


	public String getMessage() {
	  return message;
	  }
	  
	  public void setMessage(String string) {
	  message = string;
	  }	 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	 public TextAreaActionForm() {
		  super();
		  }

	
}
package com.montran.beans;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

@SuppressWarnings("serial")
public class UserLoginForm extends ActionForm {

	private int id;
	private String userName;
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	 @Override
	    public void reset(ActionMapping mapping, HttpServletRequest request) {
	        this.password = null;
	    }
	 

@Override
public ActionErrors validate(ActionMapping mapping,HttpServletRequest request)
{
	ActionErrors ae = new ActionErrors();
	if(userName.equals(""))
	{
		ae.add("userName",new ActionMessage("msg"));
	}
	if(password.equals(""))
	{
		ae.add("password",new ActionMessage("msg1"));
	}
	return ae;
}


}




package com.montran.beans;

import org.apache.struts.action.ActionForm;

public class PropertyUpdateForm extends ActionForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4854453647547629623L;
	private int id;
	private String pname;
	private String paddress;
	private int price;
	private int pcontact;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPaddress() {
		return paddress;
	}
	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPcontact() {
		return pcontact;
	}
	public void setPcontact(int pcontact) {
		this.pcontact = pcontact;
	}
}


package com.montran.beans;

import java.util.List;

import org.apache.struts.action.ActionForm;

import com.montran.pojo.PropertyAdd;

@SuppressWarnings("serial")
public class PropertyShowForm extends ActionForm{
	
		private int id;
		private String pname;
		private String paddress;
		private int price;
		private int pcontact;
		List<PropertyAdd> propertylist;
		
		public List<PropertyAdd> getPropertylist() {
			return propertylist;
		}

		public void setPropertylist(List<PropertyAdd> propertylist) {
			this.propertylist = propertylist;
		}
	
		public String getPaddress() {
			return paddress;
		}
		public void setPaddress(String paddress) {
			this.paddress = paddress;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public int getPcontact() {
			return pcontact;
		}
		public void setPcontact(int pcontact) {
			this.pcontact = pcontact;
		}
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
	
		public String getPname() {
			return pname;
		}
		public void setPname(String pname) {
			this.pname = pname;
		}		
}



package com.montran.beans;

import org.apache.struts.action.ActionForm;

@SuppressWarnings("serial")
public class PropertyDeleteForm extends ActionForm {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}

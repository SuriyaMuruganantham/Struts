package com.montran.beans;

import java.util.List;

import org.apache.struts.action.ActionForm;

import com.montran.pojo.FinalPropertyAdd;

@SuppressWarnings("serial")
public class FinalPropertyShowForm extends ActionForm{
	
	private int id;
	private String pname;
	private String paddress;
	private int price;
	private int pcontact;
	List<FinalPropertyAdd> finalpropertylist;
	
	public List<FinalPropertyAdd> getPropertylist() {
		return finalpropertylist;
	}
	public void setPropertylist(List<FinalPropertyAdd> finalpropertylist) {
		this.finalpropertylist = finalpropertylist;
	}

	public String getPaddress() {
		return paddress;
	}
	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPcontact() {
		return pcontact;
	}
	public void setPcontact(int pcontact) {
		this.pcontact = pcontact;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}

}
